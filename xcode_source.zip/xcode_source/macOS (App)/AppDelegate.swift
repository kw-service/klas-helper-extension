//
//  AppDelegate.swift
//  macOS (App)
//
//  Created by basamg on 10/23/25.
//

import Cocoa

@main
class AppDelegate: NSObject, NSApplicationDelegate {
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Safari Extension은 메인 앱이 단순한 래퍼 역할만 함
    }
    
    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }
    
    // 이 메서드를 추가하면 경고가 사라집니다
    func applicationSupportsSecureRestorableState() -> Bool {
        return true
    }
}
